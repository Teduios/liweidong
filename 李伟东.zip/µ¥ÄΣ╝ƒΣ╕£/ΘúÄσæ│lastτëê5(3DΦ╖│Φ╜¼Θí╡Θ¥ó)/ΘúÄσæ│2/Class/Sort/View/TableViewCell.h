//
//  TableViewCell.h
//  风味2
//
//  Created by tarena on 15/12/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LWDSort.h"
@interface TableViewCell : UITableViewCell
@property(nonatomic,strong)LWDSort * sort;
@property (weak, nonatomic) IBOutlet UIImageView *ImageView;

@end
