//
//  LWDScrollView.h
//  风味2
//
//  Created by tarena on 15/12/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LWDScrollView : UIView
@property(nonatomic,strong)UIPageControl * pc;
@property(nonatomic,assign)NSInteger page;
-(void)getCurrentPage:(void(^)(long page))currentPage;

@end
