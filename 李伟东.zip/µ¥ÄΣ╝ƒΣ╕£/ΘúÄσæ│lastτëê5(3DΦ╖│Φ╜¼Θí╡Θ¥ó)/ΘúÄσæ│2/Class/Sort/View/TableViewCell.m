//
//  TableViewCell.m
//  风味2
//
//  Created by tarena on 15/12/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TableViewCell.h"

@interface TableViewCell ()

@property (weak, nonatomic) IBOutlet UILabel *menuLabel;

@end
@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (void)setSort:(LWDSort *)sort
{
    self.menuLabel.text = sort.type;

}
@end
