//
//  LWDCollectionViewCell.m
//  风味2
//
//  Created by tarena on 15/12/22.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDCollectionViewCell.h"
#import "UIImageView+WebCache.h"
@interface LWDCollectionViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;


@end
@implementation LWDCollectionViewCell
- (void)setMenu:(LWDMenu *)menu
{
    //图片
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:menu.albums] placeholderImage:[UIImage imageNamed:@"cell.png"]];
    self.titleLabel.text = menu.title;
}

@end
