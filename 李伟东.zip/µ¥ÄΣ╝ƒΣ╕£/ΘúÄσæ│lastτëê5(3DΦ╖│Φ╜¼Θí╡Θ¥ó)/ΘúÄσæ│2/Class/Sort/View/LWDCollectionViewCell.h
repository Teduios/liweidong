//
//  LWDCollectionViewCell.h
//  风味2
//
//  Created by tarena on 15/12/22.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LWDMenu.h"
@interface LWDCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)LWDMenu * menu;
@end
