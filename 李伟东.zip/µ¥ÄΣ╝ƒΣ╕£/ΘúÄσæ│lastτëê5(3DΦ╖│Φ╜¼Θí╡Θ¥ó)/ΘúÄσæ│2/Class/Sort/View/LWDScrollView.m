//
//  LWDScrollView.m
//  风味2
//
//  Created by tarena on 15/12/14.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDScrollView.h"
#import "TableViewCell.h"
@interface LWDScrollView ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView * sv;
@end
@implementation LWDScrollView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //1滚动视图
        UIScrollView * sv =[[UIScrollView alloc]init];
        self.sv=sv;
        sv.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
        [self addSubview:sv];
        //姿势图
        for (int i = 0; i<9 ; i++) {
            NSString * imageName = [NSString stringWithFormat:@"1-%d.png",i+1];
            UIImageView * iv = [[UIImageView alloc]initWithImage:[UIImage imageNamed:imageName]];
            iv.frame = CGRectMake(i*sv.bounds.size.width, 0, sv.bounds.size.width, sv.bounds.size.height);
            [sv addSubview:iv];
            sv.bounces =NO;
            sv.showsHorizontalScrollIndicator = NO;
            sv.scrollEnabled = YES;
            sv.pagingEnabled = YES;
            
            sv.contentSize = CGSizeMake(9*sv.bounds.size.width, sv.bounds.size.height);
            
            [self addSubview:sv];
        }
        
        UIPageControl * pc = [[UIPageControl alloc]init];
        self.pc=pc;
        pc.frame = CGRectMake(0, self.bounds.size.height - 30, self.bounds.size.width, 40);
        
        pc.pageIndicatorTintColor = [UIColor whiteColor];
        pc.numberOfPages = 9;
        pc.currentPageIndicatorTintColor = [UIColor redColor];
        pc.userInteractionEnabled =YES;
        [self addSubview:pc];
        //定时
        [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(runTime) userInfo:nil repeats:YES];

    }
    return self;
}

-(void)runTime
{
    self.page = self.pc.currentPage;
    self.page++;
    if (self.page ==9) {
        self.page = 0;
    }
    
    self.pc.currentPage = self.page;
    [self scrollView];
}
-(void)scrollView
{
    self.page = self.pc.currentPage;
    [self.sv scrollRectToVisible:CGRectMake(self.sv.bounds.size.width*self.page, 0, self.sv.bounds.size.width, self.sv.bounds.size.height) animated:NO];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@"---------");
}

-(void)getCurrentPage:(void (^)(long))currentPage
{
    currentPage(self.pc.currentPage);
}

@end
