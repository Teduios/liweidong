//
//  LWDSort.h
//  风味
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LWDSort : NSObject
@property(nonatomic,assign)int id;
@property(nonatomic,assign)int tid;
@property(nonatomic,strong)NSString * type;
+(id)json:dic;

@end
