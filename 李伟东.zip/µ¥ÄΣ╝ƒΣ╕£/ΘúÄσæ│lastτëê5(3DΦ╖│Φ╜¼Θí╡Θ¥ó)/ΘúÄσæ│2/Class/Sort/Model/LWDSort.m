//
//  LWDSort.m
//  风味
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDSort.h"

@implementation LWDSort
+(id)json:dic{
    return [[self alloc] initWithjsonDic:dic];
}

- (id)initWithjsonDic:(NSDictionary *)dic {
    if (self = [super init]) {
        self.type = dic[@"type"];
    }
    return self;
}
@end
