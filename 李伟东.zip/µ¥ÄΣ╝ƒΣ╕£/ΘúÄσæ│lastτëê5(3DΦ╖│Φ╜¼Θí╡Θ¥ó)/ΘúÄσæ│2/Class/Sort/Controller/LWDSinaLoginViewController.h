//
//  LWDSinaLoginViewController.h
//  风味2
//
//  Created by tarena on 15/12/24.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuViewController.h"
@interface LWDSinaLoginViewController : UIViewController
@property(nonatomic,strong)LeftMenuViewController *leftMenu;
@end
