//
//  LWDBigPhotoViewController.m
//  风味2
//
//  Created by tarena on 15/12/23.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDBigPhotoViewController.h"
#import "LWDMenu.h"
//#import "UIImageView+WebCache.h"
@interface LWDBigPhotoViewController ()<UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *changeImageView;
@property(nonatomic,strong)CADisplayLink* link;
@property(nonatomic)BOOL play;
@property (weak, nonatomic) IBOutlet UIButton *btn;
@property(nonatomic,assign)int count;
@end

@implementation LWDBigPhotoViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.btn.imageView setRoundLayer];
    LWDMenu * menu = self.keyMenu;
     [self.changeImageView sd_setImageWithURL:[NSURL URLWithString:menu.albums] placeholderImage:[UIImage imageNamed:@"cell.jpg"]];
    
    //添加捏合手势
    UIPinchGestureRecognizer* pinchGR=[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinch:)];
    //代理************************
    pinchGR.delegate=self;
    [self.view addGestureRecognizer:pinchGR];
    //拖拽
    UIPanGestureRecognizer* panGR=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    
    [self.view addGestureRecognizer:panGR];
    
    //添加一个支持双击的手势
    UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    tapGR.numberOfTapsRequired=1;
    [self.view addGestureRecognizer:tapGR];

}
- (IBAction)clickCancel:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)pinch:(UIPinchGestureRecognizer*)gr

{
    //基于当前的状态变化
    //self.imageView.transform=CGAffineTransformMakeScale(gr.scale, gr.scale);
    //
    self.changeImageView.transform=CGAffineTransformScale(self.changeImageView.transform, gr.scale, gr.scale);
    //本次已经使用过了scale为了不再叠加，则将比率制成1
    gr.scale=1;
}
-(void)pan:(UIPanGestureRecognizer*)gr
{
    
    //手势移动到了某点
    //[gr locationInView:]
    //手势移动了多少
    //[gr translationInView:]
    //方式一
    CGPoint distance=[gr translationInView:self.changeImageView];
    self.changeImageView.transform=CGAffineTransformTranslate(self.changeImageView.transform, distance.x, distance.y);
    //归零
    [gr setTranslation:CGPointZero inView:self.changeImageView];
}
-(void)tap:(UIPanGestureRecognizer*)gr
{
    //通过系统提供的一个常量，将trasforme恢复
    self.changeImageView.transform=CGAffineTransformIdentity;
}
//-----------------------------------------------------
- (IBAction)DBtn:(id)sender {
    self.count++;
    if (self.count%2 == 0) {
        [self.btn setImage:[UIImage imageNamed:@"moImage.png"] forState:UIControlStateNormal];
    } else {
        [self.btn setImage:[UIImage imageNamed:@"play1.png"] forState:UIControlStateNormal];
    }
    [self rotationImageView];
}
//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
-(void)rotationImageView
{
    self.play=!self.play;
    
    self.link.paused=!self.play;
}
- (CADisplayLink *)link
{
    if (!_link) {
        _link=[CADisplayLink displayLinkWithTarget:self selector:@selector(rotation)];
        [_link addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    }
    return _link;
    
}
//此方法会在一秒钟连续调用60次,,,,,,,,设定2秒旋转2PI;
-(void)rotation
{
    self.changeImageView.layer.transform=CATransform3DRotate(self.changeImageView.layer.transform, M_PI*2/120,0, 0, 1);
}

//-----------------------------------------------------
@end
