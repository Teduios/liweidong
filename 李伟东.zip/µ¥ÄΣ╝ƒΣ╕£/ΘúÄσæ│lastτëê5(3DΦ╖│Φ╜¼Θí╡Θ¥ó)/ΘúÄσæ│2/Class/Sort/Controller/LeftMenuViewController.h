//
//  LeftMenuViewController.h
//  BaseProject
//
//  Created by tarena on 15/12/19.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseViewController.h"

@interface LeftMenuViewController : BaseViewController
@property(nonatomic,strong)NSString *value;
@property(nonatomic,strong)UIButton *button;
@end
