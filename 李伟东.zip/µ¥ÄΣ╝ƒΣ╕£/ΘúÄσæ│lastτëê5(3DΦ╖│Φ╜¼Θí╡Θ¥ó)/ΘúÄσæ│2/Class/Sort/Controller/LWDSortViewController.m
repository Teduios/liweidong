//
//  LWDSortViewController.m
//  风味2
//
//  Created by tarena on 15/12/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDSortViewController.h"
#import "LWDSort.h"
#import "LWDMenuCollectionViewController.h"
#import "TableViewCell.h"
#import "LWDScrollView.h"
#import "LWDRandomMenu.h"
/**第三方框架*/
//#import "MBProgressHUD+KR.h"
//#import "AFHTTPRequestOperationManager.h"
//#import "Masonry.h"
//#import "MJRefresh.h"
//#import "RESideMenu.h"
@interface LWDSortViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSString * filePath;
@property(nonatomic,strong)NSArray * array;
@property(nonatomic,strong)UIImageView * backgroundImageView;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)LWDScrollView * scrollView;

@property(nonatomic,strong)NSArray *menuFoods;
@property(nonatomic,strong)NSString * infoPath;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *leftBtn;
@end

@implementation LWDSortViewController
- (NSArray *)menuFoods {
    if(_menuFoods == nil) {
        _menuFoods = [NSArray arrayWithContentsOfFile:self.infoPath];
    }
    return _menuFoods;
}

- (NSArray *)array
{
    if (!_array) {
        _array = [NSArray array];
    }
    return _array;
}
static NSString * identifier = @"cell";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.infoPath=[[NSBundle mainBundle] pathForResource:@"menuList" ofType:@"plist"];
    [self setscrolView];
    [self setTableView];
    //[self setSort];
    NSString * documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    self.filePath = [documentsPath stringByAppendingPathComponent:@"sort.plist"];
    [self.tableView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:identifier];
    //[MBProgressHUD showMessage:@"正在加载"];
     [self loadData];
    //1创建
    UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    tapGR.numberOfTapsRequired=1;
    tapGR.numberOfTouchesRequired=1;
    //3添加手势到某视图上
    [self.scrollView addGestureRecognizer:tapGR];
    
    //背景图
    self.backgroundImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64 + self.scrollView.bounds.size.height, self.view.bounds.size.width, self.view.bounds.size.height*0.7)];
    self.backgroundImageView.image = [UIImage imageNamed:@"Bg.png"];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view insertSubview:self.backgroundImageView atIndex:0];
}
-(void)showLeftMenu
{
    CATransition *transition = [CATransition animation];
    transition.duration = 1.0f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromLeft;
    transition.delegate = self;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    //     显示侧边栏
    [self.sideMenuViewController presentLeftMenuViewController];
}


//手势发生时执行tap方法，并且系统将发生的手势封装成对象，作为参数传入
-(void)tap:(UITapGestureRecognizer *)gr
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.delegate = self;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];

    self.scrollView.page = self.scrollView.pc.currentPage;
    LWDMenuCollectionViewController * menuCollectionViewController = [[LWDMenuCollectionViewController alloc]init];
    __block long currentPage = nil;
    [self.scrollView getCurrentPage:^(long page) {
        currentPage = page;
    }];
    menuCollectionViewController.keymenu = self.menuFoods[currentPage];
    [self.navigationController pushViewController:menuCollectionViewController animated:YES];
}

-(void)setscrolView
{
    LWDScrollView * scrollView = [[LWDScrollView alloc]initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height*0.3)];
    self.scrollView = scrollView;
    [self.view addSubview:scrollView];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64 + 5 + self.scrollView.bounds.size.height, self.view.bounds.size.width, self.view.bounds.size.height*0.7)];
    [self.view addSubview:self.tableView];
    self.tableView.delegate =self;
    self.tableView.dataSource = self;
}
-(void)loadData
{
    //创建请求管理
    AFHTTPRequestOperationManager * mgr = [AFHTTPRequestOperationManager manager];
    NSString * urlStr = [NSString stringWithFormat:@"http://apis.haoservice.com/lifeservice/cook/category?key=%@",KEYPATH];
    NSMutableDictionary * params = [NSMutableDictionary dictionary];
    //请求
    [mgr GET:urlStr parameters:params success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [MBProgressHUD showSuccess:@"加载成功"];
        [MBProgressHUD hideHUD];
        [MBProgressHUD hideHUDForView:self.tableView];
        [responseObject writeToFile:self.filePath atomically:YES];
        
        //获取微博字典的数组
        NSArray * dicArr = responseObject[@"result"];
        NSLog(@"%@",responseObject);
        self.array = [self fromJson:dicArr];
        NSLog(@"%@",self.array);
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
}
-(NSArray *)fromJson:dicArr
{
    NSMutableArray * arrMutableArray = [NSMutableArray array];
    for (NSDictionary * dic in dicArr) {
        LWDSort * sort = [LWDSort json:dic];
        [arrMutableArray addObject:sort];
    }
    return [arrMutableArray copy];
}
#pragma mark tableViewDelegate
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count ;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    cell.backgroundColor = [UIColor colorWithWhite:0 alpha:0];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    //获取模型对象
    LWDSort * sort = self.array[indexPath.row];
    //标题
    cell.sort = sort;
    NSString * imageName = [NSString stringWithFormat:@"%ld.png",indexPath.row+1];
    cell.ImageView.image = [UIImage imageNamed:imageName];
    return cell;
}
/**一答*/
/** 选中某一行 切换到菜单控制器 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.delegate = self;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];

    
    LWDMenuCollectionViewController * menu = [[LWDMenuCollectionViewController alloc]init];
    menu.keymenu = self.menuFoods[arc4random()%self.menuFoods.count];
    [self.navigationController pushViewController:menu animated:YES];
    
}



//自动设置高度
-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 164;
}
- (IBAction)gotoLeftMenu:(id)sender
{
    
    [self showLeftMenu];
}
- (IBAction)clickPlay:(id)sender {
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.delegate = self;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    LWDRandomMenu *random = [self.storyboard instantiateViewControllerWithIdentifier:@"random"];
    [self.navigationController pushViewController:random animated:YES];
    //TabBar* t= [self.storyboard instantiateViewControllerWithIdentifier:@"tab"];
    
    //2push
}
@end
