//
//  LWDSinaLoginViewController.m
//  风味2
//
//  Created by tarena on 15/12/24.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDSinaLoginViewController.h"
//#define  APPKEY       @"2075708624"
//#define  REDIRECT_URI @"http://www.tedu.cn"
//#define  APPSECRET    @"36a3d3dec55af644cd94a316fdd8bfd8"
#define  APPKEY       @"3893301452"
#define  REDIRECT_URI @"http://www.tedu.cn"
#define  APPSECRET    @"c5d9ce0901e2bcffefd10f1c0c8cd513"
#import "NSString+md5.h"
#define WIDTH 100
#define HEIGHT 64
@interface LWDSinaLoginViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)NSMutableDictionary *parameters;
@end

@implementation LWDSinaLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /* 按照新浪官方文档发送web请求 */
    NSString  *urlStr = [NSString stringWithFormat:@"https://api.weibo.com/oauth2/authorize?client_id=%@&redirect_uri=%@"
                         ,APPKEY,REDIRECT_URI];
    /**
     *  设置webView
     */
    UIWebView * webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, HEIGHT, self.view.bounds.size.width, self.view.bounds.size.height - HEIGHT)];
    [self.view addSubview:webView];
    /**
     *  设置cancel按钮
     */
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT)];
    [btn setImage:[UIImage imageNamed:@"左箭头.png"] forState:UIControlStateNormal];
    [btn setTitle:@"cancel" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(clickCancel) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    UIImageView *iv = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, HEIGHT)];
    iv.image = [UIImage imageNamed:@"矩形@2x.png"];
    [self.view addSubview:iv];
    /* 设置webView的代理 */
    webView.delegate = self;
    NSURL *url = [NSURL URLWithString:urlStr];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *urlPath = request.URL.absoluteString;
    /* urlPath中包含 http://www.tedu.cn/?code=  */
    NSRange  range = [urlPath rangeOfString:[NSString stringWithFormat:@"%@%@",REDIRECT_URI,@"/?code="]];
    NSString *code = nil;
    if(range.length > 0){
        code = [urlPath substringFromIndex:range.length];
        /* 使用code 换取access_token */
        [self accessTokenWithCode:code];
        return NO;
    }
    return YES;
}
/** 使用code 换取access_token */
- (void) accessTokenWithCode:(NSString*)code
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager  manager];
    NSString *urlStr = @"https://api.weibo.com/oauth2/access_token";
    self.parameters = [NSMutableDictionary dictionary];
    /* 按照官方文档填写参数 */
    _parameters[@"client_id"] = APPKEY;
    _parameters[@"client_secret"] = APPSECRET;
    _parameters[@"grant_type"] = @"authorization_code";
    _parameters[@"code"] = code;
    _parameters[@"redirect_uri"] = REDIRECT_URI;
    [manager POST:urlStr parameters:_parameters success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [MBProgressHUD showMessage:@"正在登陆..."];
        sleep(2);
        [MBProgressHUD showSuccess:@"登录成功"];
        self.leftMenu.value = @"已登录";
        
        [self dismissViewControllerAnimated:self completion:nil];
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        self.leftMenu.value = @"已登录";
        self.leftMenu.button.hidden = YES;
        [self dismissViewControllerAnimated:self completion:nil];
    }];
    
}
-(void)clickCancel{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)dealloc
{
    _parameters = nil;
    [_parameters removeAllObjects];
}
@end
