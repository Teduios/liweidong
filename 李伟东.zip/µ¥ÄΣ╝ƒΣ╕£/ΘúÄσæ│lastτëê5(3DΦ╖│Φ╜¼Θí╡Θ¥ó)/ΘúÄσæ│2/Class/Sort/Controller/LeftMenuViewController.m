//
//  LeftMenuViewController.m
//  BaseProject
//
//  Created by tarena on 15/12/19.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LeftMenuViewController.h"
#import "LWDPhotoCollectionViewController.h"
#import "LWDAppIntroViewController.h"
#import "leftTableViewCell.h"
#import "LWDSinaLoginViewController.h"

//#import "RESideMenu.h"
//#import "UIImageView+KRRoundImageView.h"
@interface LeftMenuViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)NSString * filePath;
@property(nonatomic,strong)NSArray *menuPhotoArray;
@property(nonatomic,strong)UIImageView * imageView;
@property(nonatomic,assign)int count;
@property(nonatomic,strong)UIButton *button1;
@property(nonatomic,weak)UIView *coverView;
@property(nonatomic,strong)UIButton *btn;
@end
#define left 20
#define top 70  
#define Width 80
#define Height 40
#define TableWidth 200
#define TableHeight 300
#define imageToTable 20
#define thirdToHeight 20
#define popWidth 100
#define popH 75
@implementation LeftMenuViewController
static NSString *identifier  = @"cell";
- (NSArray *)menuPhotoArray {
    if(_menuPhotoArray == nil) {
        _menuPhotoArray = [NSArray arrayWithContentsOfFile:self.filePath];
    }
    return _menuPhotoArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.filePath=[[NSBundle mainBundle] pathForResource:@"menuPhoto" ofType:@"plist"];
    self.view.backgroundColor=[UIColor grayColor];
    //背景图
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:self.view.bounds];
    imageView.image = [UIImage imageNamed:@"Bg.png"];
    [self.view addSubview:imageView];
    //箭头图
    UIButton *btn=[UIButton buttonWithType:0];
    [btn setImage:[UIImage imageNamed:@"箭头@2x.png"] forState:UIControlStateNormal];
    self.btn = btn;
    btn.frame =CGRectMake(0, left*2, Height, Height);
    [self.view addSubview:btn];
    //设置已登录按钮
    UIButton *button1 = [[UIButton alloc]initWithFrame:CGRectMake(left/2, left*2, Width+Height, Height)];
    self.button1 = button1;
    button1.userInteractionEnabled = NO;
    [button1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    button1.backgroundColor= [UIColor clearColor];
    

    [self.view addSubview:button1];
    [self setTableView];
    [self.tableView registerNib:[UINib nibWithNibName:@"leftTableViewCell" bundle:nil] forCellReuseIdentifier:identifier];
    
    //设置第三方登陆
    //1图
    UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectMake(left, top+Height+TableHeight+imageToTable, TableWidth, imageToTable-10)];
    imageV.image = [UIImage imageNamed:@"第三方账号快速登录@2x.png"];
    [self.view addSubview:imageV];
    //2  设置1个按钮
    UIButton *BtnSina=[UIButton buttonWithType:0];
    self.button = BtnSina;
    [BtnSina setImage:[UIImage imageNamed:@"登录按钮on@3x.png"] forState:UIControlStateNormal];
    BtnSina.frame =CGRectMake(left,top+Height+TableHeight+imageToTable+imageToTable-10+thirdToHeight, TableWidth, TableWidth/3);
    [self.view addSubview:BtnSina];
    [BtnSina addTarget:self action:@selector(gotoSina) forControlEvents:UIControlEventTouchUpInside];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewDidLoad];
    [self.button1 setTitle:self.value forState:UIControlStateNormal];
    
    if ([self.value isEqualToString:@"已登录"]) {
        self.button1.userInteractionEnabled = YES;
        [self.button1 addTarget:self action:@selector(gotoPop) forControlEvents:UIControlEventTouchUpInside];
        [self.btn.imageView setRoundLayer];
        [self.btn setImage:[UIImage imageNamed:@"login.png"] forState:UIControlStateNormal];
    }
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, top + Height, TableWidth, TableHeight)];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    self.tableView.delegate =self;
    self.tableView.dataSource = self;
    
}
//----------------------------
-(void)gotoPop
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    UIView *cover = [[UIView alloc]init];
    cover.backgroundColor = [UIColor clearColor];
    //cover.backgroundColor = [UIColor redColor];
    cover.frame = window.bounds;
    [window addSubview:cover];
    self.coverView = cover;
    
    UIImageView *menuImageView = [[UIImageView alloc]init];
    menuImageView.userInteractionEnabled = YES;
    menuImageView.image = [UIImage imageNamed:@"MoreFunctionFrame"];
    menuImageView.frame = CGRectMake((Width/2+left)/2, left*2+Height, popWidth,popH);
    [cover addSubview:menuImageView];
    //设置两个按钮 **退出按钮和 返回**
    UIButton *cancelLoginBtn1 = [[UIButton alloc]initWithFrame:CGRectMake(0, 10, 80, 30)];
    [cancelLoginBtn1 setTitle:@"退出" forState:UIControlStateNormal];
    [cancelLoginBtn1 setImage:[UIImage imageNamed:@"sidebar_nav_reading@2x.png"] forState:UIControlStateNormal];
    cancelLoginBtn1.font = [UIFont systemFontOfSize:15];
    cancelLoginBtn1.backgroundColor = [UIColor clearColor];
    [cancelLoginBtn1 addTarget:self action:@selector(cancelLogin) forControlEvents:UIControlEventTouchUpInside];
    [menuImageView addSubview:cancelLoginBtn1];
    UIButton *cancelLoginBtn2 = [[UIButton alloc]initWithFrame:CGRectMake(0, 40, 80, 30)];
    cancelLoginBtn2.font = [UIFont systemFontOfSize:15];
    [cancelLoginBtn2 setTitle:@"取消" forState:UIControlStateNormal];
    [cancelLoginBtn2 setImage:[UIImage imageNamed:@"sidebar_nav_reading@2x.png"] forState:UIControlStateNormal];
    cancelLoginBtn2.backgroundColor = [UIColor clearColor];
    [cancelLoginBtn2 addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
    [menuImageView addSubview:cancelLoginBtn2];
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    [cover addGestureRecognizer:tapGR];
}

-(void)tap:(UITapGestureRecognizer *)gr
{
    [self.coverView removeFromSuperview];
}
-(void)cancel {
   [self.coverView removeFromSuperview];
    
}
-(void)cancelLogin
{
    self.button.hidden = NO;
    //[self.button1 didChangeValueForKey:@"未登录"];
    [self.button1 setTitle:@"未登录" forState:UIControlStateNormal];
    [self.btn setImage:[UIImage imageNamed:@"箭头@2x.png"] forState:UIControlStateNormal];
    [self.coverView removeFromSuperview];
}
//---------------------------

#pragma mark 代理
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.menuPhotoArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    leftTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.textColor = [UIColor greenColor];
    cell.textLabel.text = self.menuPhotoArray[indexPath.row];
    if (indexPath.row == 0) {
        cell.imageView.image = [UIImage imageNamed:@"sidebar_nav_photo@2x.png"];
    } if (indexPath.row == 1) {
        cell.imageView.image = [UIImage imageNamed:@"sidebar_nav_news@2x.png"];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        //跳转到menuPhoto视图层
        LWDPhotoCollectionViewController *photoCollectionViewController = [LWDPhotoCollectionViewController new];
        [self presentViewController:photoCollectionViewController animated:YES completion:nil];
    } else if(indexPath.row == 1) {
        //天转到App简介视图层
        LWDAppIntroViewController *appIntroViewController = [LWDAppIntroViewController new];
        [self presentViewController:appIntroViewController animated:YES completion:nil];
    }
}
/**行高*/
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

#pragma mark --第三方登陆

-(void)gotoSina
{
    LWDSinaLoginViewController *sinaLoginViewController =  [LWDSinaLoginViewController new];
    sinaLoginViewController.leftMenu = self;
    [self presentViewController:sinaLoginViewController animated:YES completion:nil];
}
@end
