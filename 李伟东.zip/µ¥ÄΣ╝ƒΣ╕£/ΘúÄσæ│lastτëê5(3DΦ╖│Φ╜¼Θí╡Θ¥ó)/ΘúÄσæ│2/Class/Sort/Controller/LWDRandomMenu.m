//
//  LWDRandomMenu.m
//  风味2
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDRandomMenu.h"
#import "LWDMenuCollectionViewController.h"
#import "LWDMenuCollectionViewController.h"
@interface LWDRandomMenu ()<UIPickerViewDataSource,UIPickerViewDelegate>

@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
@property (weak, nonatomic) IBOutlet UILabel *fruit;
@property (weak, nonatomic) IBOutlet UILabel *menuCai;

@property (weak, nonatomic) IBOutlet UILabel *drink;
@property(nonatomic,strong)NSString * filePath;
@property(nonatomic,strong)NSArray * allFoods;
@end
@implementation LWDRandomMenu
//懒加载
- (NSArray *)allFoods
{
    if (!_allFoods) {
        
        _allFoods=[NSArray arrayWithContentsOfFile:self.filePath];
        NSLog(@"%@",_allFoods);
        NSLog(@"%ld",self.allFoods.count);
    }
    return _allFoods;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.filePath=[[NSBundle mainBundle] pathForResource:@"food" ofType:@"plist"];
    self.pickerView.delegate = self;
    self.pickerView.dataSource = self;
    //创建轻扫手势
    UISwipeGestureRecognizer* swipeGR=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipe:)];
    swipeGR.direction= UISwipeGestureRecognizerDirectionLeft;
    [self.pickerView addGestureRecognizer:swipeGR];
    [self.view addGestureRecognizer:swipeGR];
}
-(void)swipe:(UISwipeGestureRecognizer *)rq
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark  数据源
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return self.allFoods.count;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray* subArray= self.allFoods[component];
    return subArray.count;
}

#pragma mark  代理
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return self.allFoods[component][row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
    
    
    if (component==0) {
        self.fruit.text=self.allFoods[component][row];
    }else if(component==1){
        self.menuCai.text=self.allFoods[component][row];
        
    }else{
        self.drink.text=self.allFoods[component][row];
    }
    
}
- (IBAction)clickRandom:(id)sender {
    for (int component=0; component<self.allFoods.count; component++) {
        long count=[self.allFoods[component] count];
        int row=arc4random()% count;
        
        //避免每次选重复
        long oldRow = [self.pickerView selectedRowInComponent:component];
        while(row==oldRow) {
            row=arc4random()%count;
        }
        [self.pickerView selectRow:row inComponent:component animated:YES];
        
        [self pickerView:nil didSelectRow:row inComponent:component];
    }
}
- (IBAction)clickIntro:(id)sender {
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.delegate = self;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    LWDMenuCollectionViewController * menuCollectionViewController = [LWDMenuCollectionViewController new];
    menuCollectionViewController.keymenu = self.menuCai.text;
    [self.navigationController pushViewController:menuCollectionViewController animated:YES];
    
}

@end
