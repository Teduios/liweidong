//
//  LWDPhotoCollectionViewController.m
//  风味2
//
//  Created by tarena on 15/12/22.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDPhotoCollectionViewController.h"
#import "LWDCollectionViewCell.h"
#import "LWDMenu.h"
#import "LWDBigPhotoViewController.h"
//#import "MJRefresh.h"
//#import "AFHTTPRequestOperationManager.h"
//#import "MBProgressHUD+KR.h"
@interface LWDPhotoCollectionViewController ()<UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)NSString * filePath;
//服务器返回的所有菜单数据
@property(nonatomic,strong)NSMutableArray *mutableArray;
@property(nonatomic,strong)NSArray *menuFoods;
@property(nonatomic,strong)NSString * infoPath;
@property(nonatomic,strong)NSString *keymenu;
@property(nonatomic,assign)int page;

@end

@implementation LWDPhotoCollectionViewController
- (NSArray *)menuFoods {
    if(_menuFoods == nil) {
        _menuFoods = [NSArray arrayWithContentsOfFile:self.infoPath];
        NSLog(@"%@",_menuFoods);
    }
    return _menuFoods;
}
- (NSMutableArray *)mutableArray {
    if(_mutableArray == nil) {
        _mutableArray = [[NSMutableArray alloc] init];
    }
    return _mutableArray;
}

static NSString * const reuseIdentifier = @"Cell";
- (id)init {
    /***********************************
     *                               ********
     *        layout                   ********
     *                               ********
     ***********************************
     */
    
    //创建流水布局对象
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    //设置流水布局的itemSize大小
    layout.itemSize = CGSizeMake(90, 90);
//    layout.minimumInteritemSpacing=10;
//    layout.minimumLineSpacing=10;
    return [self initWithCollectionViewLayout:layout];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.infoPath=[[NSBundle mainBundle] pathForResource:@"menuList" ofType:@"plist"];
    //[self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    [self.collectionView registerNib:[UINib nibWithNibName:@"LWDCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:reuseIdentifier];
    NSString * documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    self.filePath = [documentsPath stringByAppendingPathComponent:@"Photo.plist"];
    //下拉刷新
    [self.collectionView addGifHeaderWithRefreshingTarget:self refreshingAction:@selector(reloadPhoto)];
    //[self.collectionView addLegendHeaderWithRefreshingTarget:self refreshingAction:@selector(reloadPhoto)];
    //[MBProgressHUD showSuccess:@"请求成功"];
    [self.collectionView.header beginRefreshing];
    //上拉加载
    [self.collectionView addGifFooterWithRefreshingTarget:self refreshingAction:@selector(reloadPhoto)];
    //[self.collectionView addLegendFooterWithRefreshingTarget:self refreshingAction:@selector(reloadPhoto)];
    self.keymenu = self.menuFoods[arc4random()%self.menuFoods.count];
    //self.collectionView.backgroundColor = [UIColor greenColor];
    self.collectionView.backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"collection.png"]];
    [self setcancelBtn];
}
-(void)setcancelBtn
{
    UIButton * Btn = [[UIButton alloc]initWithFrame:CGRectMake(5, 20, 70, 30)];
    [Btn setImage:[UIImage imageNamed:@"左箭头.png"] forState:UIControlStateNormal];
    [Btn setTitle:@"cancel" forState:UIControlStateNormal];
    [Btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:Btn];
}
-(void)click
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
/**上拉加载请求更多数据*/
-(void)reloadPhoto
{
    self.page++;
    NSLog(@"page%d",self.page);
    //创建请求管理
    AFHTTPRequestOperationManager * mgr = [AFHTTPRequestOperationManager manager];
    NSString *url = @"http://apis.haoservice.com/lifeservice/cook/query?";
    NSString *menu = [self.keymenu stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlStr = [NSString stringWithFormat:@"%@menu=%@&pn=%ld&rn=%d&key=%@",url,menu,(long)self.page,15,KEYPATH];
    [mgr GET:urlStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [responseObject writeToFile:self.filePath atomically:YES];
        [self.collectionView.header endRefreshing];
        [self.collectionView.footer endRefreshing];

            NSArray * dicArr = responseObject[@"result"];
            NSLog(@"%@",responseObject);
            NSArray * array = [self fromJson:dicArr];
            [self.mutableArray addObjectsFromArray:array];
            [self.collectionView reloadData];
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
    
}
-(NSMutableArray *)fromJson:dicArr
{
    NSMutableArray * arrMutableArray = [NSMutableArray array];
    for (NSDictionary * dic in dicArr) {
        LWDMenu * menu = [LWDMenu json:dic];
        [arrMutableArray addObject:menu];
    }
    return arrMutableArray;
}

#pragma mark <UICollectionViewDataSource>
//- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
//{
//    return 2;
//}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.mutableArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    LWDCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    LWDMenu * menu = self.mutableArray[indexPath.row];
    cell.menu = menu;
    return cell;
}
//点击响应
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    LWDBigPhotoViewController *bigPhotoViewController = [LWDBigPhotoViewController new];
    bigPhotoViewController.keyMenu = self.mutableArray[indexPath.row];
    [self presentViewController:bigPhotoViewController animated:YES completion:nil];
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat height=100+(arc4random()%50);
    return CGSizeMake(100, height);
}
-(void)dealloc
{
     NSLog(@"%@",[self class]);
    self.mutableArray = nil;

}
@end
