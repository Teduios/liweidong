//
//  LWDRandomMenu.h
//  风味2
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LWDRandomMenu : UIViewController

@end
