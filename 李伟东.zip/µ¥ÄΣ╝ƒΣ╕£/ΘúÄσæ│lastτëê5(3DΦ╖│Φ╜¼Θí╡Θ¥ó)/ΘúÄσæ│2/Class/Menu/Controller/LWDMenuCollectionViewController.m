//
//  LWDMenuCollectionViewController.m
//  风味2
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDMenuCollectionViewController.h"
#import "LWDMenu.h"
#import "LWDMenuCollectionViewCell.h"
#import "LWDStepCollectionViewCell.h"
#import "LWDstepCollectionViewController.h"
@interface LWDMenuCollectionViewController ()<UISearchBarDelegate>
//服务器返回的所有菜单数据
@property(nonatomic,strong)NSMutableArray *mutableArray;
@property(nonatomic,strong)NSString * filePath;
@property(nonatomic,strong)LWDMenu * menu;

@property (nonatomic,assign) NSInteger page;

@property(nonatomic,weak)UIView *coverView;
/**
 *  用于记录搜索控制器
 */
@property(nonatomic,strong)UISearchBar *searchBar;
/**
 *  menuList.plist
 */
@property(nonatomic,strong)NSArray *menuFoods;
@property(nonatomic,strong)NSString * infoPath;
@property(nonatomic,strong)LWDMenuCollectionViewCell *cellView;
@end

@implementation LWDMenuCollectionViewController
- (NSArray *)menuFoods {
    if(_menuFoods == nil) {
        _menuFoods = [NSArray arrayWithContentsOfFile:self.infoPath];
    }
    return _menuFoods;
}
- (NSString *)keymenu
{
    if (!_keymenu) {
        _keymenu = [[NSString alloc]init];
    }
    return _keymenu;
}
- (NSMutableArray *)mutableArray {
    if(_mutableArray == nil) {
        _mutableArray = [[NSMutableArray alloc] init];
    }
    return _mutableArray;
}
static NSString * const reuseIdentifier = @"Cell";
- (id)init {
    /***********************************
     *                               ********
     *        layout                   ********
     *                               ********
     ***********************************
     */
    
    //创建流水布局对象
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    //设置流水布局的itemSize大小
    layout.itemSize = CGSizeMake(305, 305);
    layout.sectionInset = UIEdgeInsetsMake(15, 15, 15, 15);
    return [self initWithCollectionViewLayout:layout];
}

- (void)viewDidLoad {
    [super viewDidLoad];
     self.infoPath=[[NSBundle mainBundle] pathForResource:@"menuList" ofType:@"plist"];
    
    self.navigationItem.title = @"菜系";
    self.collectionView.backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Bg.png"]];
     //self.collectionView.backgroundColor = [UIColor grayColor];
    [self.collectionView registerNib:[UINib nibWithNibName:@"LWDMenuCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:reuseIdentifier];
    NSString * documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    self.filePath = [documentsPath stringByAppendingPathComponent:@"sort.plist"];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"icon_search"] style:UIBarButtonItemStylePlain target:self action:@selector(searchClick)];
    [self setUpSearchFunction];
    self.page= 1;
    [self.collectionView addLegendFooterWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    //[self.collectionView addLegendHeaderWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    //自动显示
    //[self.collectionView.header beginRefreshing];
    //self.keymenu = @"番茄";

    [self resultFromServiceByKey];
    //创建轻扫手势
    UISwipeGestureRecognizer* swipeGR=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipe:)];
    swipeGR.direction= UISwipeGestureRecognizerDirectionLeft;
    [self.collectionView addGestureRecognizer:swipeGR];
}
-(void)swipe:(UISwipeGestureRecognizer *)rq
{
   [self dismissViewControllerAnimated:YES completion:nil];
}
/**下拉加载请求最新数据*/
-(void)loadNewData
{
    //创建请求管理
    AFHTTPRequestOperationManager * mgr = [AFHTTPRequestOperationManager manager];
    NSString *url = @"http://apis.haoservice.com/lifeservice/cook/query?";
    NSString *menu = [self.keymenu stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlStr = [NSString stringWithFormat:@"%@menu=%@&pn=%d&rn=%d&key=%@",url,menu,1,10,KEYPATH];
    [mgr GET:urlStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [responseObject writeToFile:self.filePath atomically:YES];
        [self.collectionView.header endRefreshing];
        
        //[self.collectionView.footer endRefreshing];
        [self.collectionView.footer endRefreshing];
        NSArray * dicArr = responseObject[@"result"];
        NSLog(@"%@",responseObject);
        self.mutableArray = [self fromJson:dicArr];
        [self.collectionView reloadData];
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];

}
-(void)searchClick
{
    
    self.searchBar.hidden = NO;
    self.navigationItem.rightBarButtonItem = nil;
}

-(void)resultFromServiceByKey
{
    
    //创建请求管理
    AFHTTPRequestOperationManager * mgr = [AFHTTPRequestOperationManager manager];
    NSString *url = @"http://apis.haoservice.com/lifeservice/cook/query?";
    NSString *menu = [self.keymenu stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlStr = [NSString stringWithFormat:@"%@menu=%@&pn=%d&rn=%d&key=%@",url,menu,1,10,KEYPATH];
    [mgr GET:urlStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [responseObject writeToFile:self.filePath atomically:YES];
        if ([self emptyHandle:responseObject]) {
            //[self.collectionView.footer endRefreshing];
            [self.collectionView.footer endRefreshing];
            NSArray * dicArr = responseObject[@"result"];
            NSLog(@"%@",responseObject);
            self.mutableArray = [self fromJson:dicArr];
            [self.collectionView reloadData];
        }
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
}
-(NSMutableArray *)fromJson:dicArr
{
    NSMutableArray * arrMutableArray = [NSMutableArray array];
    for (NSDictionary * dic in dicArr) {
        LWDMenu * menu = [LWDMenu json:dic];
        [arrMutableArray addObject:menu];
    }
    return arrMutableArray;
}
/**上拉加载请求更多数据*/
-(void)loadMoreData
{
    self.page++;
    NSLog(@"page%ld",self.page);
    
    //创建请求管理
    AFHTTPRequestOperationManager * mgr = [AFHTTPRequestOperationManager manager];
    NSString *url = @"http://apis.haoservice.com/lifeservice/cook/query?";
    NSString *menu = [self.keymenu stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlStr = [NSString stringWithFormat:@"%@menu=%@&pn=%ld&rn=%d&key=%@",url,menu,(long)self.page,10,KEYPATH];
    [mgr GET:urlStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [responseObject writeToFile:self.filePath atomically:YES];
        [self.collectionView.footer endRefreshing];
        if ([self emptyHandle:responseObject]) {
            NSArray * dicArr = responseObject[@"result"];
            NSLog(@"%@",responseObject);
            NSArray * array = [self fromJson:dicArr];
            [self.mutableArray addObjectsFromArray:array];
            [self.collectionView reloadData];
        }
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];

}


///显示详情intro
-(void)doSomething:(UIButton *)sender
{
    [self.searchBar resignFirstResponder];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    UIView *cover = [[UIView alloc]init];
   
    LWDMenu * menu = self.mutableArray[sender.tag];
   
    cover.backgroundColor = [UIColor grayColor];
    cover.frame = window.bounds;
    //cover.frame = CGRectMake(20, 64, 280, 500);
    [window addSubview:cover];
    self.coverView = cover;
    UIImageView *menuImageView = [[UIImageView alloc]init];
    menuImageView.image = [UIImage imageNamed:@"MoreFunctionFrame"];
    menuImageView.frame = CGRectMake(cover.bounds.size.width/2-150, 62, 300, 500);
    [cover addSubview:menuImageView];
    UITextView *introTextView = [[UITextView alloc]initWithFrame:menuImageView.frame];
    [introTextView setEditable:NO];
    introTextView.backgroundColor = [UIColor grayColor];
    introTextView.textColor = [UIColor whiteColor];
    introTextView.font = [UIFont fontWithName:@"Zapfino" size:15];
    [cover addSubview:introTextView];
    introTextView.userInteractionEnabled = YES;
    UICollectionViewCell *cell = (UICollectionViewCell*)sender.superview.superview;
    NSLog(@"cell%@",cell);
    
     introTextView.text = menu.intro;
    
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    [cover addGestureRecognizer:tapGR];
}

-(void)tap:(UITapGestureRecognizer *)gr
{
    [self.coverView removeFromSuperview];
}

///显示配置
- (void)doDesPloy:(UIButton *)sender
{
     [self.searchBar resignFirstResponder];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    UIView *cover = [[UIView alloc]init];
    
    LWDMenu * menu = self.mutableArray[sender.tag];
    cover.backgroundColor = [UIColor purpleColor];
    cover.frame = window.bounds;
    [window addSubview:cover];
    self.coverView = cover;
    UIImageView *menuImageView = [[UIImageView alloc]init];
    menuImageView.frame = CGRectMake(cover.bounds.size.width/2-150, 62, 300, 300);
    [cover addSubview:menuImageView];
    UILabel *ingredientsLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, cover.frame.size.width, cover.frame.size.height/2)];
    ingredientsLabel.backgroundColor = [UIColor clearColor];
    [cover addSubview:ingredientsLabel];
    ingredientsLabel.numberOfLines = 0;
    ingredientsLabel.text = menu.ingredients;
    UILabel *burdenLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, cover.frame.size.height/2, cover.frame.size.width, cover.frame.size.height/2)];
    burdenLabel.backgroundColor = [UIColor clearColor];
    [cover addSubview:burdenLabel];
    burdenLabel.numberOfLines = 0;
    burdenLabel.text = menu.burden;
    
    UICollectionViewCell *cell = (UICollectionViewCell*)sender.superview.superview;
    NSLog(@"cell%@",cell);
    
    
    
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    [cover addGestureRecognizer:tapGR];

}
-(void)doTemp:(UIButton*)sender
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.delegate = self;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    
    LWDstepCollectionViewController * stepCollectionViewController = [[LWDstepCollectionViewController alloc]init];
    stepCollectionViewController.keymenu = self.keymenu;
    stepCollectionViewController.btnTag = sender.tag;
    stepCollectionViewController.indexPage = self.page;
    [self.navigationController pushViewController:stepCollectionViewController animated:YES];
}
#pragma mark <UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.mutableArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    LWDMenuCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    LWDMenu * menu = self.mutableArray[indexPath.row];
    cell.delegate = self;
    cell.menu = menu;
    cell.tempBtn.tag = indexPath.row;
    cell.introBtn.tag = indexPath.row;
    cell.PeiZhiBtn.tag = indexPath.row;
    return cell;
}
#pragma mark --- UISearchBarDelegate

-(BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    return YES;
}

-(BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
    self.page=1;
    return YES;
}
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSLog(@"编辑完成执行操作");
    self.keymenu = self.searchBar.text;
    [self.searchBar resignFirstResponder];
    [self resultFromServiceByKey];
}
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    self.searchBar.hidden = YES;
    self.searchBar.text = @"";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"icon_search"] style:UIBarButtonItemStylePlain target:self action:@selector(searchClick)];
    [self.searchBar resignFirstResponder];
}
/**
 *  配置搜索控制器
 */
-(void)setUpSearchFunction
{
    /**
     *  创建搜索控制器的实例
     */
    self.searchBar = [[UISearchBar alloc]init];
    /**
     *  设置搜索条的尺寸为自适应
     */
    [self.searchBar sizeToFit];
    /** 在当前主控制器的表头添加searchBar*/
    self.navigationItem.titleView = self.searchBar;
    self.searchBar.hidden = YES;
    /** 设置搜索控制器的结果更新代理对象*/
    // 所以设置searchBar的代理
    self.searchBar.delegate = self;
    self.searchBar.showsCancelButton = YES;
    self.searchBar.keyboardType = UIKeyboardTypeDefault;
    [self.view addSubview:self.searchBar];
}

-(BOOL)emptyHandle:(NSDictionary *)dic
{
    if ([dic[@"error_code"] intValue]!=0)
    {
        if ([dic[@"error_code"] intValue]==203002)
        {
            [self showMessage:@"非常抱歉，您搜索的佳肴我们还没有收录^~^"];
        }else
        {
            [self showMessage:@"出现未知错误请稍后再试^~^"];
        }
        return NO;
    }
    else
    {
        return YES;
    }
}
-(void)showMessage:(NSString *)msg
{
    MBProgressHUD *progress=[MBProgressHUD showHUDAddedTo:self.view animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.labelText = msg;
    [progress hide:YES afterDelay:2];
}
//-(void)dealloc
//{    NSLog(@"%@",[self class]);
//    self.mutableArray = nil;
//}
@end
