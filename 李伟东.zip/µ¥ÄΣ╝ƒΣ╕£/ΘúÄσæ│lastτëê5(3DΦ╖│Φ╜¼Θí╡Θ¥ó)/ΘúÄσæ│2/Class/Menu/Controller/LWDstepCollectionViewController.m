//
//  LWDstepCollectionViewController.m
//  风味2
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDstepCollectionViewController.h"
#import "LWDMenu.h"
#import "LWDStepCollectionViewCell.h"
@interface LWDstepCollectionViewController ()<UMSocialUIDelegate>
@property(nonatomic,strong)NSMutableArray *mutableArray;
@property (nonatomic,strong) NSMutableString *shareContext;
@property (nonatomic,strong) UIButton *btn;
@property (nonatomic,strong) NSString *urlStr;
@end

@implementation LWDstepCollectionViewController
- (NSMutableArray *)mutableArray {
    if(_mutableArray == nil) {
        _mutableArray = [[NSMutableArray alloc] init];
    }
    return _mutableArray;
}
- (id)init {
    /***********************************
     *                               ********
     *        layout                   ********
     *                               ********
     ***********************************
     */
    
    //创建流水布局对象
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    //设置流水布局的itemSize大小
    layout.itemSize = CGSizeMake(305, 305);
    layout.sectionInset = UIEdgeInsetsMake(15, 15, 15, 15);
    return [self initWithCollectionViewLayout:layout];
}

static NSString* identifier = @"cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"temp";
    [self.collectionView registerNib:[UINib nibWithNibName:@"LWDStepCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:identifier];
    self.collectionView.backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"intro.png"]];
    //分享
    [self configShareBtn];
    [self setMenuData];
    //创建轻扫手势
    UISwipeGestureRecognizer* swipeGR=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipe:)];
    swipeGR.direction= UISwipeGestureRecognizerDirectionLeft | UISwipeGestureRecognizerDirectionRight;
    [self.collectionView addGestureRecognizer:swipeGR];
}
-(void)swipe:(UISwipeGestureRecognizer *)rq
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)setMenuData
{
    //创建请求管理
    AFHTTPRequestOperationManager * mgr = [AFHTTPRequestOperationManager manager];
    NSString *url = @"http://apis.haoservice.com/lifeservice/cook/query?";
    NSString *menu = [self.keymenu stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlStr = [NSString stringWithFormat:@"%@menu=%@&pn=%ld&rn=%d&key=%@",url,menu,self.indexPage,10,KEYPATH];
    [mgr GET:urlStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        //获取菜单字典的数组
        NSLog(@"%ld",(long)self.btnTag);
        NSArray * dicArr = responseObject[@"result"][self.btnTag%10][@"steps"];
        self.mutableArray = [self fromJsonStep:dicArr];
        //分享
        [self.shareContext appendString:responseObject[@"result"][self.btnTag%10][@"title"]];
        self.urlStr = responseObject[@"result"][self.btnTag%10][@"albums"];
        [self.collectionView reloadData];
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
}
-(NSMutableArray *)fromJsonStep:dicArr
{
    NSMutableArray * arrMutableArray = [NSMutableArray array];
    for (NSDictionary * dic in dicArr) {
        LWDMenu * menu = [LWDMenu jsonStep:dic];
        [arrMutableArray addObject:menu];
    }
    return arrMutableArray;
}
#pragma mark <UICollectionViewDataSource>


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
     return self.mutableArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    LWDStepCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
     LWDMenu * menu = self.mutableArray[indexPath.row];
    cell.menuStep = menu;
    return cell;
}
#pragma mark --- 配置分享功能

-(void)configShareBtn
{
    self.shareContext = [[NSMutableString alloc] initWithString:@"今天新学的一道菜，分享出来大家也去学学吧："];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btn = btn;
    [btn setBackgroundImage:[UIImage imageNamed:@"owner_good_share"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(shareContent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-20);
        make.bottom.mas_equalTo(-50);
        make.size.mas_equalTo(50);
    }];
}

-(void)shareContent
{
    //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
    //如果需要分享回调，请将delegate对象设置self，并实现下面的回调方法
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"567a8c4d67e58e1d14004220"
                                      shareText: self.shareContext
                                     shareImage:[UIImage imageNamed:@"icon"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToFacebook,nil]
                                       delegate:self];
    [[UMSocialData defaultData].urlResource setResourceType:UMSocialUrlResourceTypeImage url:self.urlStr];
}
/**
 *  将分享后的状态返回
 */
-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response
{
    //根据`responseCode`得到发送结果,如果分享成功
    if(response.responseCode == UMSResponseCodeSuccess)
    {
        //得到分享到的微博平台名
        NSLog(@"share to sns name is %@",[[response.data allKeys] objectAtIndex:0]);
    }
}
-(void)dealloc {

 NSLog(@"%@",[self class]);
    self.mutableArray = nil;
}
@end
