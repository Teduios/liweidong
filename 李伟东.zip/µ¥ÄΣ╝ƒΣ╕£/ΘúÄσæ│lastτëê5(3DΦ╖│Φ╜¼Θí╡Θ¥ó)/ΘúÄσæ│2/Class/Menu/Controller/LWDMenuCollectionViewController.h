//
//  LWDMenuCollectionViewController.h
//  风味2
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LWDMenuCollectionViewController : UICollectionViewController
@property (nonatomic,strong) NSString * dishName;
-(void)doSomething:(UIButton*)sender;
-(void)doDesPloy:(UIButton*)sender;
-(void)doTemp:(UIButton*)sender;

@property (nonatomic,strong) NSString *keymenu;

@end
