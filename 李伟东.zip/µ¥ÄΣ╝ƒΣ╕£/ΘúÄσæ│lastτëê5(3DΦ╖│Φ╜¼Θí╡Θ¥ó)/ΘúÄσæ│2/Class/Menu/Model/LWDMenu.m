//
//  LWDMenu.m
//  风味
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDMenu.h"

@implementation LWDMenu
+(id)json:dic{
    return [[self alloc] initWithjsonDic:dic];
}

- (id)initWithjsonDic:(NSDictionary *)dic {
    if (self = [super init]) {
        self.title = dic[@"title"];
        self.tags = dic[@"tags"];
        self.intro = dic[@"intro"];
        self.ingredients = dic[@"ingredients"];
        self.burden = dic[@"burden"];
        self.albums = dic[@"albums"];
//        self.img = dic[@"steps"][0][@"img"];
//        self.step = dic[@"steps"][0][@"step"];
    }
    return self;
}
+ (id)jsonStep:(id)dic
{
    return [[self alloc] initWithjsonStepDic:dic];
}
- (id)initWithjsonStepDic:(NSDictionary *)dic {
     if (self = [super init]) {
         self.img = dic[@"img"];
         self.step = dic[@"step"];
     }
    return self;
}
@end
