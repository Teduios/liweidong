//
//  LWDMenu.h
//  风味
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LWDMenu : NSObject

@property(nonatomic,strong)NSString * menu;
@property(nonatomic,assign)int pn;
@property(nonatomic,assign)int rn;
@property(nonatomic,strong)NSString * title;
@property(nonatomic,strong)NSString * tags;
@property(nonatomic,strong)NSString * intro;
@property(nonatomic,strong)NSString * ingredients;
@property(nonatomic,strong)NSString * burden;
@property(nonatomic,strong)NSString * albums;
@property(nonatomic,strong)NSString * img;
@property(nonatomic,strong)NSString * step;

+(id)json:dic;
+(id)jsonStep:(id)dic;
@end
