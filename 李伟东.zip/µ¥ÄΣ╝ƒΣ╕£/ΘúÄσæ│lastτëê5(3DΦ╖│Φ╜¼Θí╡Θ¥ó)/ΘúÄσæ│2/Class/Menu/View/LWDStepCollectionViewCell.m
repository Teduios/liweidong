//
//  LWDStepCollectionViewCell.m
//  风味2
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDStepCollectionViewCell.h"
#import "UIImageView+WebCache.h"
@interface LWDStepCollectionViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *stepImageView;
@property (weak, nonatomic) IBOutlet UITextView *stepTextView;

@end
@implementation LWDStepCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (void)setMenuStep:(LWDMenu *)menuStep
{
    
    //图片
    [self.stepImageView sd_setImageWithURL:[NSURL URLWithString:menuStep.img] placeholderImage:[UIImage imageNamed:@"cell.jpg"]];
    //title
    self.stepTextView.text = menuStep.step;
    
    
}
@end
