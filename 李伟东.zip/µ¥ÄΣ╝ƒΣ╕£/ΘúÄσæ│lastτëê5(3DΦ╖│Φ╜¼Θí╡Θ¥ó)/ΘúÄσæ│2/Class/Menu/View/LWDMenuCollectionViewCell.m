//
//  LWDMenuCollectionViewCell.m
//  风味
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LWDMenuCollectionViewCell.h"
#import "LWDMenuCollectionViewController.h"
#import "UIImageView+WebCache.h"
@interface LWDMenuCollectionViewCell ()

@property (weak, nonatomic) IBOutlet UILabel *title;

- (IBAction)ingredientsBurden:(id)sender;
- (IBAction)temp:(id)sender;




@end
@implementation LWDMenuCollectionViewCell



- (IBAction)ingredientsBurden:(id)sender {
    
  [self.delegate doDesPloy:(UIButton *)sender];
}

- (IBAction)temp:(id)sender {
    [self.delegate doTemp:(UIButton *)sender];
}
- (IBAction)intro:(id)sender
{
    [self.delegate doSomething:(UIButton *)sender];
}
- (void)setMenu:(LWDMenu *)menu
{
    
    //图片
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:menu.albums] placeholderImage:[UIImage imageNamed:@"cell.png"]];
    //title
    self.title.text = menu.title;
}

@end
