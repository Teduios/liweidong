//
//  LWDMenuCollectionViewCell.h
//  风味
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LWDMenu.h"
@class LWDMenuCollectionViewController;
@interface LWDMenuCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)LWDMenu * menu;
@property(nonatomic,weak) LWDMenuCollectionViewController *delegate;
@property (weak, nonatomic) IBOutlet UIButton *tempBtn;
@property (weak, nonatomic) IBOutlet UIButton *PeiZhiBtn;
@property (weak, nonatomic) IBOutlet UIButton *introBtn;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end
